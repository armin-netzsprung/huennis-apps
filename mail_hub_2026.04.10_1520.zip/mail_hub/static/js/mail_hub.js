/* static/js/mail_hub.js */

// 1. LAYOUT STEUERUNG
function setLayout(mode) {
    const hub = document.getElementById('mail-hub-main');
    const list = document.getElementById('mail-list');
    
    if (mode === 'vertical') {
        hub.classList.replace('layout-horizontal', 'layout-vertical');
        list.style.width = ''; // Löscht die feste Breite vom horizontalen Ziehen
    } else {
        hub.classList.replace('layout-vertical', 'layout-horizontal');
        list.style.height = ''; // Löscht die feste Höhe vom vertikalen Ziehen
    }
}

// 2. RESIZER LOGIK (Unterstützt X und Y Achse)
const makeResizable = (resizerId, panelId) => {
    const resizer = document.getElementById(resizerId);
    const panel = document.getElementById(panelId);
    if (!resizer || !panel) return;

    let x = 0, y = 0, w = 0, h = 0;

    const mouseDownHandler = (e) => {
        x = e.clientX;
        y = e.clientY;
        const rect = panel.getBoundingClientRect();
        w = rect.width;
        h = rect.height;
        document.addEventListener('mousemove', mouseMoveHandler);
        document.addEventListener('mouseup', mouseUpHandler);
        resizer.classList.add('bg-amber-500');
    };

    const mouseMoveHandler = (e) => {
        const hub = document.getElementById('mail-hub-main');
        const isVerticalLayout = hub.classList.contains('layout-vertical');
        
        if (resizerId === 'resizer-1') {
            // Sidebar: Immer Breite ändern
            const dx = e.clientX - x;
            panel.style.width = `${w + dx}px`;
        } else if (resizerId === 'resizer-2') {
            if (isVerticalLayout) {
                // Liste oben: Höhe ändern
                const dy = e.clientY - y;
                panel.style.height = `${h + dy}px`;
                panel.style.width = '100%';
            } else {
                // Liste links: Breite ändern
                const dx = e.clientX - x;
                panel.style.width = `${w + dx}px`;
                panel.style.height = 'auto';
            }
        }
    };

    const mouseUpHandler = () => {
        document.removeEventListener('mousemove', mouseMoveHandler);
        document.removeEventListener('mouseup', mouseUpHandler);
        resizer.classList.remove('bg-amber-500');
    };

    resizer.addEventListener('mousedown', mouseDownHandler);
};

// 3. EDITOR & FORMULAR
function initEditor() {
    if (tinymce.get('mail-editor')) {
        tinymce.get('mail-editor').remove();
    }

    tinymce.init({
        selector: '#mail-editor',
        license_key: 'gpl',
        height: '100%',
        promotion: false,
        statusbar: false,
        menubar: false,
        
        // KORREKTUR: 'paste' und 'removeformat' hier entfernen, 
        // da sie im Core enthalten sind.
        plugins: 'lists link autolink charmap emoticons code',
        
        // In der Toolbar dürfen sie natürlich bleiben
        toolbar: 'undo redo | blocks | ' +
                 'bold italic underline | forecolor | ' +
                 'bullist numlist | link emoticons | ' +
                 'removeformat code',

        invalid_elements: 'script,applet,iframe', 
        forced_root_block: 'div',
        
        setup: function (editor) {
            editor.on('change', function () {
                editor.save();
            });
        },
        content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px; color: #334155; }'
    });
}

// In deinem Initialisierungs-Block:
document.body.addEventListener('htmx:afterSwap', (evt) => {
    lucide.createIcons();
    
    // Prüfe, ob das getauschte Element den Editor enthält
    if (document.getElementById('mail-editor')) {
        initEditor();
    }
});

function updateAttachmentList(input) {
    const display = document.getElementById('attachment-list-display');
    if (!display) return;
    display.innerHTML = '';
    Array.from(input.files).forEach(file => {
        const span = document.createElement('span');
        span.className = 'bg-slate-100 border border-slate-200 px-2 py-1 rounded shadow-sm flex items-center gap-1 text-[10px]';
        span.innerHTML = `<i data-lucide="file" class="w-3 h-3"></i> ${file.name}`;
        display.appendChild(span);
    });
    lucide.createIcons();
}

function submitMailForm() {
    const form = document.querySelector('#compose-form');
    if (form) {
        if (tinymce.get('mail-editor')) tinymce.get('mail-editor').save();
        form.requestSubmit();
    }
}

// 4. INITIALISIERUNG
document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    makeResizable('resizer-1', 'sidebar');
    makeResizable('resizer-2', 'mail-list');
});

document.body.addEventListener('htmx:afterSwap', (evt) => {
    lucide.createIcons();
    if (document.getElementById('mail-editor')) initEditor();
    // Falls das Formular neu geladen wird, Resizer ggf. neu binden (optional)
});
